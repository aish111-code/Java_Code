import json
import requests
import sys
import getopt
## Use 'pip install pyyaml' to import the below 
import yaml

import warnings
warnings.filterwarnings("ignore")

sys.path.insert(0, '../common')
from common_tools import common_tools

## Usage :
# python item_delete.py --dcs DC01 --user user --password pwd --trigger "triggername" --template "template" --discovery "discoveryname"


def get_input():
    argv=sys.argv[1:]
    opts,args=getopt.getopt(argv,"d:u:p:i:t:a",["dcs=","user=","password=","trigger=","template=","discovery="])
    # script --dc DC --u user -p password -item itemname -template template
    opts=dict(opts)
    keys = opts.keys()
    values = opts.values()
    template = opts['--template']
    trigger = opts['--trigger']
    discovery_name = opts['--discovery']
    dcList = opts['--dcs']

    inputData = {}
    [inputData['template'],inputData['triggerName'],inputData['discoveryName']] = [template,trigger,discovery_name]
    creds = [opts['--user'],opts['--password']]
    dcList = opts['--dcs'].split(',')

    return inputData, creds, dcList

def get_trigger_prototype_data(token,zabbix_url,inputData,):
    # Get template id details
    template = inputData['template']
    triggerName = inputData['triggerName']
    discoveryName = inputData['discoveryName']
    template_finder =  json.dumps({"jsonrpc": "2.0",
                            "method": "template.get",
                            "params": {
                                "output":"extend",
                                "filter":{
                                    "host":template
                                }
                                },
                            "auth": token,
                            "id": 1
                            })
    output = requests.post(url=zabbix_url, data=template_finder, verify=False, headers={"Content-Type": "application/json"})
    hostid = output.json()['result'][0]['templateid']

    # Get discovery rule id 
    discovery_finder = json.dumps({"jsonrpc": "2.0",
                            "method": "discoveryrule.get",
                            "params": {
                                "output":"extend",
                                "hostids":hostid,
                                "filter":{
                                    "name":discoveryName
                                }
                                },
                            "auth": token,
                            "id": 1
                            })
    output = requests.post(url=zabbix_url, data=discovery_finder, verify=False, headers={"Content-Type": "application/json"})
    discoveryid = output.json()['result'][0]['itemid']   

    # Get item prototype details

    item_finder =  json.dumps({"jsonrpc": "2.0",
                            "method": "triggerprototype.get",
                            "params": {
                                "output":"extend",
                                "hostids": hostid,
                                "discoveryids":discoveryid,
                                "search":{
                                    "name":triggerName
                                }
                                },
                            "auth": token,
                            "id": 1
                            })

    output = requests.post(url=zabbix_url, data=item_finder, verify=False, headers={"Content-Type": "application/json"})
    try :
        output = output.json()['result'][0]
    except : 
        output = "Trigger Prototype not found"
    return output


def delete_trigger_prototype(zabbix_url, token, itemid):

    deletePayload = json.dumps({
        "jsonrpc":"2.0",
        "method":"triggerprototype.delete",
        "params":[itemid],
        "auth": token,
        "id":1
    })

    output = requests.post(url=zabbix_url, data=deletePayload, verify=False, headers={"Content-Type": "application/json"})
    return output

###### Main Script #####
inputData,creds ,dcList = get_input()
user = creds[0]
password = creds[1]
common = common_tools(user,password)

with open("../environment_configs/zabbix_environment.yaml", "r") as stream:
    try:
        config = yaml.safe_load(stream)
    except yaml.YAMLError as exc:
        print(exc)

print(dcList)


for dc in dcList :
    print('###############################')
    print(dc)
    zabbix_url = config[dc]['env-url']

    try :
        token = common.authenticate(zabbix_url)
    except :
        print("Login failed in "+dc)
        continue

    if token=="Invalid credentials":
        print("Invalid credentials for "+ dc)
        continue

    triggerDetails = get_trigger_prototype_data(token,zabbix_url,inputData)
    #if multple trigger id present exit.
    if triggerDetails== "Trigger Prototype not found" :
        print("Trigger Prototype/Template not found in "+dc)
    else:
        itemid=triggerDetails['triggerid']
        print(itemid)

        try :
            output = delete_trigger_prototype(zabbix_url, token, itemid)

            if 'error' in  output.json().keys():
                error = output.json()['error']['data']
                print(error)
            
            else :
                print(output.json())
        except :
            print("Trigger Prototype deletion failed for "+dc)
        print('\n')