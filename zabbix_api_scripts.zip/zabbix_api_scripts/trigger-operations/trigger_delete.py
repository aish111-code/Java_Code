import json
import requests
import sys
import getopt
## Use 'pip install pyyaml' to import the below 
import yaml
import warnings
warnings.filterwarnings("ignore")

sys.path.insert(0, '../common')
from common_tools import common_tools

## Usage :
# python trigger_delete.py --dcs DC23,DC01 --user user --password pwd --trigger "trigger" --template "template"
# dcs : dcs on which the trigger has to be added

def get_input():
    argv=sys.argv[1:]
    opts,args=getopt.getopt(argv,"d:u:p:i:t:",["dcs=","user=","password=","trigger=","template="])
    opts=dict(opts)
    keys = opts.keys()
    values = opts.values()
    template = opts['--template']
    #template=template.replace('\"','')
    trigger = opts['--trigger']
    #trigger=trigger.replace('\"','')
    dcList = opts['--dcs']

    inputData = {}
    [inputData['template'],inputData['triggerName']] = [template,trigger]
    creds = [opts['--user'],opts['--password']]
    dcList = opts['--dcs'].split(',')
    print("template")
    print(template)
    print("dclist")
    print(dcList)
    print("trigger name")
    print(trigger)
    # print(opts['--user'])
    # print(opts['--password'])

    return inputData, creds, dcList

def get_trigger_data(token,zabbix_url,inputData):
    # Get trigger details
    template = inputData['template']
    triggerName = inputData['triggerName']
    # print("display values passed to get_trigger_data method ")
    # print(triggerName)
    # print(zabbix_url)
    # print(template)
    trigger_finder =  json.dumps({"jsonrpc": "2.0",
                            "method": "trigger.get",
                            "params": {
                                "output":"extend",
                                "host": template,
                                "search":{
                                    "description":triggerName
                                }
                                },
                            "auth": token,
                            "id": 1
                            })
    print("print input")
    print(trigger_finder)

    output = requests.post(url=zabbix_url, data=trigger_finder, verify=False, headers={"Content-Type": "application/json"})   
    print("printing output.txt")
    print(output.text)
    output = output.json()['result']
    #print(output)
    return output

def delete_trigger(zabbix_url, token, triggerid):
    createPayload = json.dumps({
        "jsonrpc":"2.0",
        "method":"trigger.delete",
        "params":[triggerid],
        "auth": token,
        "id":1
    })

    output = requests.post(url=zabbix_url, data=createPayload, verify=False, headers={"Content-Type": "application/json"})
    return output



###### Main Script #####

inputData,creds ,dcList = get_input()
user = creds[0]
password = creds[1]
common = common_tools(user,password)
with open("../environment_configs/zabbix_environment.yaml", "r") as stream:
    try:
        config = yaml.safe_load(stream)
    except yaml.YAMLError as exc:
        print(exc)


template = inputData['template']
print(dcList)
for dc in dcList :
    print('###############################')
    print(dc)
    zabbix_url = config[dc]['env-url']
    # if dc==inputData['dc'] :
    #     continue
    try :
        token = common.authenticate(zabbix_url)
        print("token details")
        print(token)
    except :
        print("Login failed in "+dc)
        continue
    try :
        triggerDetails = get_trigger_data(token,zabbix_url,inputData)
        print(triggerDetails)
    except :
        print("triggerDetails fetch failed in "+dc)
        continue
    #if multple trigger id present exit.
    size=len(triggerDetails)
    if size > 1:
        print("duplicate trigger name present .Trigger deletion failed in "+dc)
        continue
    triggerid=triggerDetails[0]['triggerid']
    print(triggerid)
    try :
        output = delete_trigger(zabbix_url, token, triggerid)

        if 'error' in  output.json().keys():
            error = output.json()['error']['data']
            print(error)
        
        else :
            print("Trigger:"+inputData['triggerName']+" Deletion success in "+dc)
            print(output.json())
    except :
        print(" Trigger deletion failed for "+dc)
    print('\n')

