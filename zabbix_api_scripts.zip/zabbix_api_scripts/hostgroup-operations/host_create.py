
import time
import json
import requests
import sys
import getpass

import warnings
warnings.filterwarnings("ignore")

# user=str(sys.argv[2])
# password=str(sys.argv[3])
user=' '
password=' '

switcher = {
    "23": "https://zabbix-emea-primary.cld.ondemand.com/api_jsonrpc.php",
	"41": "https://zabbix-americas-primary.ondemand.com/api_jsonrpc.php",
    "25": "https://zabbix-qa.cld.ondemand.com/api_jsonrpc.php",
    "30": "https://zabbix-dc30.cld.ondemand.com/api_jsonrpc.php",
    "33": "https://zabbix-dc33.cld.ondemand.com/api_jsonrpc.php",
    "50": "https://zabbix-dc50.cld.ondemand.com/api_jsonrpc.php",
    "51": "https://zabbix-dc50.cld.ondemand.com/api_jsonrpc.php",
    "52": "https://zabbix-dc52.cld.ondemand.com/api_jsonrpc.php",
    "55": "https://zabbix-dc55.cld.ondemand.com/api_jsonrpc.php",
    "56": "https://zabbix-dc55.cld.ondemand.com/api_jsonrpc.php",
    "60": "https://zabbix-dc60.cld.ondemand.com/api_jsonrpc.php",
    "61": "https://zabbix-dc60.cld.ondemand.com/api_jsonrpc.php",
    "62": "https://zabbix-dc62.cld.ondemand.com/api_jsonrpc.php",
    "64": "https://zabbix-dc64.cld.ondemand.com/api_jsonrpc.php",
    "65": "https://zabbix-dc64.cld.ondemand.com/api_jsonrpc.php",
    "66": "https://zabbix-dc66.cld.ondemand.com/api_jsonrpc.php",
    "67": "https://zabbix-dc66.cld.ondemand.com/api_jsonrpc.php",
    "68": "https://zabbix-dc68.cld.ondemand.com/api_jsonrpc.php",
    "69": "https://zabbix-dc68.cld.ondemand.com/api_jsonrpc.php",
    "70": "https://zabbix-dc70.cld.ondemand.com/api_jsonrpc.php",
    "71": "https://zabbix-dc70.cld.ondemand.com/api_jsonrpc.php",
	"74": "https://zabbix-dc74.cld.ondemand.com/api_jsonrpc.php"
}

def getHeaders():
    headers = {
        "Content-Type": "application/json"
    }
    return headers

def getDetail(url,payload):
    headers = getHeaders()
    r = requests.post(url=url, data=payload, verify=False, headers=headers)
    output = {"code": str(r.status_code), "content": r.json()}
    return output


with open("host_create","r") as fh:
 hostgroup_list=fh.read()

#  print(hosts)
 for line in hostgroup_list.split('\n') :
    print(line)
    linesplit = line.split(':')
    zbx_env = linesplit[0]
    host = linesplit[1]
    ip = linesplit[2]
    hostgroup = linesplit[3]
    template = linesplit[4]
    proxy = linesplit[5]

    zabbixurl=switcher.get(zbx_env, "nothing")
    print(zabbixurl)
    ###get login token
    token_api = json.dumps({"jsonrpc": "2.0","method": "user.login","params": {"password": password,"user": user},"id":1})
    output=getDetail(zabbixurl,token_api)
    # print(output)
    token=output['content']['result']
    get_group_id=  json.dumps({"jsonrpc": "2.0","method": "hostgroup.get","params": {"output":"extend","filter": {"name": [ hostgroup]}},"auth": token,"id": 1})
    output=getDetail(zabbixurl,get_group_id)
    obj = output['content']
    results = obj['result']
    print(results)
    for result in results:
        hostgroupid=result['groupid']
        print(hostgroupid)
    #get template id
    get_template_id=  json.dumps({"jsonrpc": "2.0","method": "template.get","params": {"output":"extend","filter": {"host": [ template]}},"auth": token,"id": 1})
    output=getDetail(zabbixurl,get_template_id)
    obj = output['content']
    results = obj['result']
    # print(results)
    for result in results:
        templateid=result['templateid']
        print(templateid)

#proxy_hostid

    get_proxy_id=  json.dumps({"jsonrpc": "2.0","method": "proxy.get","params": {"output":"extend","filter": {"host": [ proxy]}},"auth": token,"id": 1})
    output=getDetail(zabbixurl,get_proxy_id)
    obj = output['content']
    results = obj['result']
    print(results)
    for result in results:
        proxyid=result['proxyid']
        print(proxyid)
    get_host_id = json.dumps({
    "jsonrpc": "2.0",
    "method": "host.create",
    "params": {
        "host": host,
        "interfaces": [{"type": 1,
                "main": 1,
                "useip": 1,
                "ip": ip,
                "dns": "",
                "port": "10050"
            }
        ],
        "groups": [
            {
                "groupid": hostgroupid
            }
        ],
        "templates": [
            {
                "templateid": templateid
            }
        ],
            "proxy_hostid" : proxyid
    },

"auth": token,"id": 1
})
    houtput=getDetail(zabbixurl,get_host_id)
    hobj = houtput['content']
    results = hobj['result']
    print(results)
    # for result in results:
    #     hostid=result['groupids']

