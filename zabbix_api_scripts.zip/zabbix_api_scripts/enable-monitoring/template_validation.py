
import json
import requests
import sys
import getopt
import argparse
## Use 'pip install pyyaml' to import the below 
import yaml
import re
import os
import warnings
warnings.filterwarnings("ignore")
sys.path.insert(0, '../common')
from common_tools import common_tools
## Usage :
# python enable_host_validation_template.py --user user --password pwd --dc "DC01" --hostlist "hostname1,hostname2"


def get_input():
    parser = argparse.ArgumentParser(description='Script to validate Host & DC')
    parser.add_argument('--user', type=str, nargs='?', help='username')
    parser.add_argument('--password', type=str, nargs='?', help='password')
    parser.add_argument('--dc', type=str, required=True, help='dc name')
    parser.add_argument('--hostlist', type=str, required=True, help='hostlist')
    args = parser.parse_args()
    inputData = {}
    [inputData['user'], inputData['password'], inputData['dc'], inputData['hostlist']] = [args.user, args.password, args.dc, args.hostlist]
    creds = [inputData['user'],inputData['password']]
    return  inputData,creds

def get_token(inputData,creds):
    user = creds[0]
    password = creds[1]
    common = common_tools(user,password)
    with open("../environment_configs/zabbix_environment.yaml", "r") as stream:
        try:
            config = yaml.safe_load(stream)
        except yaml.YAMLError as exc:
            print(exc)

    # print(f'DC:{inputData["dc"]}')
    zabbix_url = config[inputData['dc']]['env-url']
    # print(f'ZABBIX URL: {zabbix_url}')

    try :
        token = common.authenticate(zabbix_url)
        # print(f'printing : {token}')
    except :
        print("Login failed in "+zabbix_url)
        print("---- script operation failed-----")
        print("###############################")
        exit()

    if token=="Invalid credentials":
        print("Invalid credentials for "+ zabbix_url)
        exit()
    return token

def get_template_list(inputData,token):
    with open("../environment_configs/zabbix_environment.yaml", "r") as stream:
        try:
            config = yaml.safe_load(stream)
        except yaml.YAMLError as exc:
            print(exc)
    # print(f'DC:{inputData["dc"]}')
    zabbix_url = config[inputData['dc']]['env-url']
    # print(f'ZABBIX URL: {zabbix_url}')
    payload_dict = {
    "jsonrpc": "2.0",
    "method": "template.get",
    "params": {
        "output": [
            "host"
        ]
        },
    "auth": token,
    "id": 1
    }
    headers = {
    'Content-type': 'application/json'
    }
    try:
        response = requests.request("GET", zabbix_url, headers=headers, data=json.dumps(payload_dict))
        #print ((response.json()).get('result'))
        templates = [x.get('host') for x in (response.json()).get('result')]
        #print(templates)



    except Exception as e:
        print(e)
        templates = []
    return templates

def generate_template(inputData,host):

    relative_path = "../../zbxAdm/2.2/conf/"+inputData['dc']+".hostMapping.cfg"
    # Get the absolute path by joining the current directory with the relative path
    script_dir = os.path.dirname(__file__)  # Get script's directory
    file_path = os.path.join(script_dir, relative_path)
    print("generating app templates .....")
    #print(f'Regex file path:{file_path}')
    appTemplates=[]

    with open(file_path, "r") as file:
        regex_patterns = file.readlines()
        for regex_pattern in regex_patterns:
            # Compile the regex pattern
            #print(regex_pattern)
            regex_split_array=regex_pattern.split(":")
            #below 1 line is to add ^to the starting of the regex so that it should match from starting of the line .
            #Instead of updating all hostmapping.cnf file and testing it in per script is need.this is solve VIP-pq01jamdb-ilb01 false positive vaidation #
            
            regex_to_search="^"+regex_split_array[0]
            
            additionalAppTemplate=""
            y=re.search(regex_to_search,host)
            if(y):
                print(f'Matched regex:{regex_pattern}')
                

                if len((regex_split_array)) == 3:
                    additionalAppTemplate=regex_split_array[2].strip()
                    if additionalAppTemplate == "notemplate":
                        print("no app template since notemplate in regex line")
                    else:
                        tmp=additionalAppTemplate.split(",")
                        appTemplates.extend(tmp)
                        ###

                        hostGroupTemplateArray=[]
                        HgArray=regex_split_array[1].strip().split(",")
                        filtered_array=[element for element in HgArray if "_" in element]
                        # print("filtered array")
                        # print(filtered_array)
                        groups=[]
                        for element in filtered_array:
                            parts = element.split('_')
                            prefixes = []
                            prefix = ''
                            for part in parts:
                                if prefix:
                                    prefix += '_'+part
                                    prefixes.append(prefix)
                                else:
                                    prefix = 'T'
                                
                            groups.extend(prefixes)
                        hostGroupTemplateArray=list(set(groups))
                        # print('printing hostgroup template array')
                        # print(hostGroupTemplateArray)

                        ##seach hostgroup template* with template.get 
                        token=get_token(inputData,creds)
                        all_templates=get_template_list(inputData,token)
                        # print("printing all templates")
                        # #print(all_templates)
                        matches=[]
                        for element in all_templates:
                            for hostGroupTemplate in hostGroupTemplateArray:
                                if re.search(hostGroupTemplate,element):
                                    if (element == hostGroupTemplate) :
                                        matches.append(element)
                        appTemplates.extend(matches)
                        matches1=[]
                        for hostGroupelement in filtered_array:
                            tmp1=hostGroupelement.split("_",1)
                            hostGroupTemplate1="T_"+tmp1[1]
                            matches1.append(hostGroupTemplate1)
                        
                        matches=[]
                        for element in all_templates:
                            for hostGroupTemplate in matches1:
                                if re.search(hostGroupTemplate,element):
                                    if ( hostGroupTemplate+"_" in element):
                                        matches.append(element)
                        appTemplates.extend(matches)                                   
                elif len((regex_split_array)) == 2:
                    hostGroupTemplateArray=[]
                    HgArray=regex_split_array[1].strip().split(",")
                    filtered_array=[element for element in HgArray if "_" in element]
                    # print("filtered array")
                    # print(filtered_array)
                    groups=[]
                    for element in filtered_array:
                        parts = element.split('_')
                        prefixes = []
                        prefix = ''
                        for part in parts:
                            if prefix:
                                prefix += '_'+part
                                prefixes.append(prefix)
                            else:
                                prefix = 'T'
                            
                        groups.extend(prefixes)
                    hostGroupTemplateArray=list(set(groups))
                    # print("regex has only 2 part")
                    # print('printing hostgroup template array')
                    # print(hostGroupTemplateArray)

                    ##seach hostgroup template* with template.get 
                    token=get_token(inputData,creds)
                    all_templates=get_template_list(inputData,token)
                    # print("printing all templates")
                    # #print(all_templates)
                    matches=[]
                    for element in all_templates:
                        for hostGroupTemplate in hostGroupTemplateArray:
                            if re.search(hostGroupTemplate,element):
                                if (element == hostGroupTemplate) :
                                    matches.append(element)
                    appTemplates.extend(matches)
                    matches1=[]
                    for hostGroupelement in filtered_array:
                        tmp1=hostGroupelement.split("_",1)
                        hostGroupTemplate1="T_"+tmp1[1]
                        matches1.append(hostGroupTemplate1)
                    
                    matches=[]
                    for element in all_templates:
                        for hostGroupTemplate in matches1:
                            if re.search(hostGroupTemplate,element):
                                if ( hostGroupTemplate+"_" in element):
                                    matches.append(element)
                    appTemplates.extend(matches)



                else:
                    print("Error in application hostmapping regex")
    appTemplates1=(set(appTemplates))
    appTemplates= list(appTemplates1)
    if len((appTemplates)) == 0 and additionalAppTemplate != "notemplate" :
        print("No regex match found")
    else:
        print(f"app templates:{appTemplates} ")
###fectching os template####
    relative_path = "os.hostmapping.cfg"
    script_dir = os.path.dirname(__file__)  # Get script's directory
    file_path = os.path.join(script_dir, relative_path)
    print("generating os templates .....")
    # print(f'Regex file path:{file_path}')
    osTemplates=[]

    with open(file_path, "r") as file:
        regex_patterns = file.readlines()
        for regex_pattern in regex_patterns:

            regex_split_array=regex_pattern.split(":")
            y=re.search(regex_split_array[0],host)
            if(y):
                print(f'Matched regex:{regex_pattern}')

                if len((regex_split_array)) == 2:
                    osTemplatestring=regex_split_array[1].strip()
                    osTemplates=osTemplatestring.split(",")
                else:
                    print("Error in os regex")
    print(f'os templates:{osTemplates}')
    Templates=[]
    Templates.extend(appTemplates)
    Templates.extend(osTemplates)
    #taken only unique values from both above array
    Templates1=(set(Templates))
    Templates= list(Templates1)
    generatedTemplates={}
    generatedTemplates[host]=sorted(Templates)
    return generatedTemplates

    
def get_templates(inputData,creds,hostname):
    user = creds[0]
    password = creds[1]
    common = common_tools(user,password)
    with open("../environment_configs/zabbix_environment.yaml", "r") as stream:
        try:
            config = yaml.safe_load(stream)
        except yaml.YAMLError as exc:
            print(exc)

    zabbix_url = config[inputData['dc']]['env-url']
    try :
        token = common.authenticate(zabbix_url)
        # print(f'printing : {token}')
    except :
        print("Login failed in "+zabbix_url)
        print("---- script operation failed-----")
        print("###############################")
        exit()

    if token=="Invalid credentials":
        print("Invalid credentials for "+ zabbix_url)
        exit()
    templates = {}
    url = zabbix_url
    payload_dict = {
    "jsonrpc": "2.0",
    "method": "host.get",
    "params": {
        "filter": {
        "host": [
            hostname
        ]
        },
        "selectGroups": [
            "name"
        ],
        "selectParentTemplates": [ "name" ]
    },
    "auth": token,
    "id": 1
    }
    headers = {
    'Content-type': 'application/json'
    }
    try:
        response = requests.request("GET", url, headers=headers, data=json.dumps(payload_dict))
        #print(response)
        templates[hostname] = [x.get('name') for x in (response.json()).get('result')[0].get('parentTemplates')]
        templates[hostname] =sorted(templates[hostname])
    except Exception as e:
        print(e)
        templates[hostname] = []
    return templates





# def get_host_data(token,zabbix_url,host):
#     try:
#         host_finder =  json.dumps({"jsonrpc": "2.0",
#                                 "method": "host.get",
#                                 "params": {
#                                     "filter":{
#                                     "host": [host]
#                                 }},
#                                 "auth": token,
#                                 "id": 1
#                                 })
#         output = requests.post(url=zabbix_url, data=host_finder, verify=False, headers={"Content-Type": "application/json"})   
#         #print(output)
#         #print(output.text)
#         output = output.json()['result'][0]
#         #print(output)
#         return output
#     except Exception as e:
#         print(e)
#         print(f"{host} not found in zabbix. Please check in zabbix ui and enter correct hostname.zabbix url inventory:https://operate360.cfapps.us10.hana.ondemand.com/index.html#/operations/linkmanager/services/tools/links")
#         sys.exit(1)

###### Main Script #####

inputData,creds = get_input()
user = creds[0]
password = creds[1]
common = common_tools(user,password)
with open("../environment_configs/zabbix_environment.yaml", "r") as stream:
    try:
        config = yaml.safe_load(stream)
    except yaml.YAMLError as exc:
        print(exc)

print('###############################')
# print(f'DC:{inputData["dc"]}')
zabbix_url = config[inputData['dc']]['env-url']
print(f'ZABBIX URL: {zabbix_url}')
# print(user)
# print(password)
S_outputlist=[]
F_outputlist=[]
with open('template_success.txt', 'w') as file1, open('template_failed.txt', 'w') as file2:
    for hostname in inputData['hostlist'].split(',')[:20]:
        # print(f'hostname:{hostname}')
        generated_templates=generate_template(inputData,hostname)
        #print(f'Generated templates          : {generated_templates}')      
        zabbix_templates=get_templates(inputData,creds,hostname)
        #print(f'Templates in zabbix: {zabbix_templates}')
        for group in generated_templates:
            generated_templates_list = generated_templates.get(group, [])
            print(generated_templates_list)
            zabbix_template_list = zabbix_templates.get(group, [])
            print(zabbix_template_list)
            # if generated_templates_list and all(item in  zabbix_template_list for item in generated_templates_list):
            if generated_templates_list == zabbix_template_list:
                if len(zabbix_template_list) == 0:
                    F_outputlist.append(str(group))
                    # print(f'Validation failed - no template attached in Zabbix UI')
                    F_outputlist.append('Validation failed - no template attached in Zabbix UI')
                else:
                    S_outputlist.append(str(group))
                    S_outputlist.append('Configured Templates in regEx: '+str(generated_templates))
                    S_outputlist.append('Configured Templates in zabbix: '+str(zabbix_templates))

                    file1.write(f'{group}\n')
            else:
                F_outputlist.append(str(group))
                # print(f'{group} : Validation failed - Mismatch in generated templates and templates in Zabbix UI')
                F_outputlist.append(' Validation failed - Mismatch in generated templates and templates in Zabbix UI')
                F_outputlist.append('Configured Templates in regEx: '+str(generated_templates))
                F_outputlist.append('Configured Templates in zabbix: '+str(zabbix_templates))
                
                file2.write(f'{group}\n')

print("-------------------------- Template validation summary --------------------------")
print("\n************* Validation success nodes ************* ")

for line in S_outputlist:
    print(line)
print("\n************* Validation Failed nodes *************")

for line in F_outputlist:
    print(line) 
print('\n ---------------------------------------------------------------------------------\n')
