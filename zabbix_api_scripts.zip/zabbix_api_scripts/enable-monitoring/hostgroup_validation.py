import requests
import argparse
import os
from configparser import ConfigParser
import re
import json
import yaml
import warnings
import sys
warnings.filterwarnings("ignore")
sys.path.insert(0, '../common')
from common_tools import common_tools

# python3 hostgroup_validation.py --user user --password pwd --dc "DC01" --hostlist "hostname1,hostname2"

def get_input():
    parser = argparse.ArgumentParser(description='Script to validate Host & DC')
    parser.add_argument('--user', type=str, nargs='?', help='username')
    parser.add_argument('--password', type=str, nargs='?', help='password')
    parser.add_argument('--dc', type=str, required=True, help='dc name')
    parser.add_argument('--hostlist', type=str, required=True, help='hostlist')
    args = parser.parse_args()
    inputData = {}
    [inputData['user'], inputData['password'], inputData['dc'], inputData['hostlist']] = [args.user, args.password, args.dc, args.hostlist]
    creds = [inputData['user'],inputData['password']]
    return  inputData,creds

def check_file_present(inputData):
    file_path = "../../zbxAdm/2.2/conf/"+inputData['dc']+".hostMapping.cfg"

    if os.path.exists(file_path):
        return True
    else:
        return False

def get_hostgroup_from_config_file(inputData):
    file_path = "../../zbxAdm/2.2/conf/"+inputData['dc']+".hostMapping.cfg"
    print(f'\nPath of Config: {file_path}')    
    host_groups = {}
    host_map = {}
    results = {}
    with open(file_path) as f:
        for line in f:
            line = line.strip()
            if ':' in line and '#' not in line:
                key, value = re.split(':', line, 1)
                host_groups[key]=value
    for hostname in inputData['hostlist'].split(',')[:20]: 
        found = False
        for pattern, mapping in host_groups.items():
            match = re.match(pattern, hostname)
            groups = set()
            if match:
                results[hostname] = mapping
                groups = generate_host_groups(results[hostname])
                found = True
                break
        if not found:
            print(f'\nHost Group from Config File not found for: {hostname} \n') 
        host_map[hostname.strip()] = groups            
    return(host_map)

def get_host_groups(inputData,creds):
    user = creds[0]
    password = creds[1]
    common = common_tools(user,password)
    with open("../environment_configs/zabbix_environment.yaml", "r") as stream:
        try:
            config = yaml.safe_load(stream)
        except yaml.YAMLError as exc:
            print(exc)
    zabbix_url = config[inputData['dc']]['env-url']
    print(f'\nZabbix URL: {zabbix_url}')
    try :
        token = common.authenticate(zabbix_url)
    except :
        print("Login failed in "+zabbix_url)
        print("---- script operation failed-----")
        exit()

    if token=="Invalid credentials":
        print("Invalid credentials for "+ zabbix_url)
        exit()
    groups = {}
    for hostname in inputData['hostlist'].split(',')[:20]:
        url = zabbix_url
        payload_dict = {
        "jsonrpc": "2.0",
        "method": "host.get",
        "params": {
            "filter": {
            "host": [
                hostname
            ]
            },
#selectHostGroups is used if zabbix version >= 6.4
            # "selectHostGroups": [
            #     "name"
            # ],
            "selectGroups": [
                "name"
            ]
        },
        "auth": token,
        "id": 1
        }
        headers = {
        'Content-type': 'application/json'
        }
        try:
            response = requests.request("GET", url, headers=headers, data=json.dumps(payload_dict))
            #hostgroups is used if zabbix version >= 6.4
            # groups[hostname] = [x.get('name') for x in (response.json()).get('result')[0].get('hostgroups')]
            groups[hostname] = [x.get('name') for x in (response.json()).get('result')[0].get('groups')]
        except Exception as e:
            print(e)
            groups[hostname] = []
    return groups
  
def contains_colon(host_groups):
    return ':' in host_groups
    
def generate_host_groups(host_groups):
    groups = []
    if(contains_colon(host_groups)):
        split_list = host_groups.split(':')
        host_groups = split_list[0]
    for big_group in host_groups.split(','):
        parts = big_group.split('_')
        prefixes = []
        prefix = ''
        for part in parts:
            if prefix:
                prefix += '_'+part
            else:
                prefix = part
            prefixes.append(prefix)
        groups.extend(prefixes)
    return list(set(groups))

if __name__ == '__main__':
    inputData,creds = get_input()
    if(len(inputData['hostlist'].split(','))>20):
        print('\n***** ***** ***** ***** ***** ***** ***** ***** ***** ***** ***** ***** ***** ***** ***** *****')
        print('You have input of more than 20 nodes but This job will only process first 20 servers in the list')
        print('***** ***** ***** ***** ***** ***** ***** ***** ***** ***** ***** ***** ***** ***** ***** ***** ')
    file_group = get_hostgroup_from_config_file(inputData)
    zabbix_group = get_host_groups(inputData,creds)
    successful_server = []
    failed_server = []
    with open('hg_success.txt', 'w') as file1, open('hg_failed.txt', 'w') as file2:
        for group in file_group:
            file_group_list = file_group.get(group, [])
            zabbix_group_list = zabbix_group.get(group, [])
            exclude_list = {'All-Live-Hosts-Maintenance', 'All-NotLive-Hosts-Maintenance'}
            filtered_zabbix_group = [item for item in zabbix_group_list if item not in exclude_list]
            if sorted(filtered_zabbix_group) == sorted(file_group_list):
                successful_server.append(group)
                file1.write(f'{group}\n')
            else:
                failed_server.append(group)
                file2.write(f'{group}\n')
    print('\n -------------------------- Hostgroup validation summary --------------------------\n')
    
    print('************* Validation success nodes *************\n')
    for server in successful_server:
        print(f'\n{server}')
        if server in zabbix_group:
            print(f'Configured hostgroups in zabbix: {server}: {sorted(zabbix_group[server])}')
        if server in file_group:
            print(f'Configured hostgroups in regEx: {server}: {sorted(file_group[server])}')

    print('\n************* Validation Failed nodes *************\n')

    for server in failed_server:
        print(f'\n{server}')
        if server in zabbix_group:
            print(f'Configured hostgroups in zabbix: {server}: {sorted(zabbix_group[server])}')
        if server in file_group:
            print(f'Configured hostgroups in regEx: {server}: {sorted(file_group[server])}')
    print('\n ---------------------------------------------------------------------------------\n')
