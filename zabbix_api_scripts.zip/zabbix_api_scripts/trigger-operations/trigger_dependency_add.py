import json
import requests
import sys
import getopt
## Use 'pip install pyyaml' to import the below 
import yaml
import warnings
import copy
warnings.filterwarnings("ignore")

sys.path.insert(0, '../common')
from common_tools import common_tools

## Usage :
# python trigger_dependency_add.py --dcs DC23,DC01 --user user --password pwd --maintrigger "triggername" --dependsontrigger "triggername" --template "template"


def get_input():
    argv=sys.argv[1:]
    opts,args=getopt.getopt(argv,"d:u:p:ot:nt:t",["dcs=","user=","password=","maintrigger=","dependsontrigger=","template="])
    opts=dict(opts)
    keys = opts.keys()
    values = opts.values()
    template = opts['--template']
    maintrigger = opts['--maintrigger']
    dependsontrigger = opts['--dependsontrigger']
    dcList = opts['--dcs']

    inputData = {}
    [inputData['template'],inputData['maintrigger'],inputData['dependsontrigger']] = [template,maintrigger,dependsontrigger]
    creds = [opts['--user'],opts['--password']]
    dcList = opts['--dcs'].split(',')

    return inputData, creds, dcList

def get_trigger_data(token,zabbix_url,inputData):
    # Get trigger details
    template = inputData['template']
    maintrigger = inputData['maintrigger']
    dependsontrigger = inputData['dependsontrigger']
    trigger_finder_template = {"jsonrpc": "2.0",
                            "method": "trigger.get",
                            "params": {
                                "output":"extend",
                                "host": template,
                                "search":{
                                    "description":"triggerName"
                                },
                                "expandExpression": "true"
                                },
                            "auth": token,
                            "id": 1
                            }

    trigger_finder_main = copy.deepcopy(trigger_finder_template)
    trigger_finder_dependson = copy.deepcopy(trigger_finder_template)
    
    trigger_finder_main["params"]["search"]["description"] = maintrigger
    trigger_finder_dependson["params"]["search"]["description"] = dependsontrigger


    trigger_finder_main = json.dumps(trigger_finder_main)
    trigger_finder_dependson = json.dumps(trigger_finder_dependson)

    output_main_trigger = requests.post(url=zabbix_url, data=trigger_finder_main, verify=False, headers={"Content-Type": "application/json"})
    output_dependson_trigger = requests.post(url=zabbix_url, data=trigger_finder_dependson, verify=False, headers={"Content-Type": "application/json"})   

    output_main_trigger = output_main_trigger.json()['result']
    output_dependson_trigger = output_dependson_trigger.json()['result']

    # print(output_main_trigger)
    # print("..............................")
    # print(output_dependson_trigger)
    return output_main_trigger,output_dependson_trigger

def trigger_dependency_add(zabbix_url, token, main_trigger_id, dependson_trigger_id):

    addPayload = json.dumps({
        "jsonrpc":"2.0",
        "method":"trigger.adddependencies",
        "params":{
            "triggerid" : main_trigger_id ,
            "dependsOnTriggerid" : dependson_trigger_id
        },
        "auth": token,
        "id":1
    })

    output = requests.post(url=zabbix_url, data=addPayload, verify=False, headers={"Content-Type": "application/json"})
    return output


###### Main Script #####

inputData,creds ,dcList = get_input()
user = creds[0]
password = creds[1]
common = common_tools(user,password)
template = inputData['template']

with open("../environment_configs/zabbix_environment.yaml", "r") as stream:
    try:
        config = yaml.safe_load(stream)
    except yaml.YAMLError as exc:
        print(exc)

print(dcList)

for dc in dcList :
    print('###############################')
    print(dc)
    zabbix_url = config[dc]['env-url']

    try :
        token = common.authenticate(zabbix_url)
        print("token details")
        print(token)
    except :
        print("Login failed in "+dc)
        continue

    try :   
        main_trigger,dependson_trigger = get_trigger_data(token,zabbix_url,inputData)
    except :
        print("TriggerDetails fetch failed in "+dc)
        exit()
    
    main_trigger_id = main_trigger[0]['triggerid']
    dependson_trigger_id = dependson_trigger[0]['triggerid']

    try :
        output = trigger_dependency_add(zabbix_url, token, main_trigger_id, dependson_trigger_id)

        if 'error' in  output.json().keys():
            error = output.json()['error']['data']
            print(error)
        
        else :
            print(output.json())
    except :
        print("Trigger dependency addition failed for "+dc)


