
import json
import requests
import sys
import getopt
## Use 'pip install pyyaml' to import the below 
import yaml
import warnings
warnings.filterwarnings("ignore")
sys.path.insert(0, '../common')
from common_tools import common_tools
## Usage :
# python host_delete.py --user user --password pwd --dc "DC01" --hostlist "hostname1,hostname2"

def get_input():
    argv=sys.argv[1:]
    opts,args=getopt.getopt(argv,"u:p:d:hl",["user=","password=","dc=","hostlist="])
    opts=dict(opts)
    keys = opts.keys()
    values = opts.values()
    inputData = {}
    creds = [opts['--user'],opts['--password']]
    dc =opts['--dc']
    hostList = opts['--hostlist'].split(',')
    return  creds,dc,hostList


def get_host_data(token,zabbix_url,host):

    host_finder =  json.dumps({"jsonrpc": "2.0",
                            "method": "host.get",
                            "params": {
                                "filter":{
                                "host": [host]
                            }},
                            "auth": token,
                            "id": 1
                            })
    output = requests.post(url=zabbix_url, data=host_finder, verify=False, headers={"Content-Type": "application/json"})   
    #print(output)
    #print(output.text)
    output = output.json()['result'][0]
    #print(output)
    return output

def delete_host(zabbix_url,token,hostid):

    createPayload = json.dumps({
        "jsonrpc":"2.0",
        "method":"host.delete",
        "params":[hostid],
        "auth": token,
        "id":1
    })
    print(createPayload)
    output = requests.post(url=zabbix_url, data=createPayload, verify=False, headers={"Content-Type": "application/json"})
    print (output)
    return output

###### Main Script #####

creds,dc,hostList = get_input()
user = creds[0]
password = creds[1]

common = common_tools(user,password)
with open("../environment_configs/zabbix_environment.yaml", "r") as stream:
    try:
        config = yaml.safe_load(stream)
    except yaml.YAMLError as exc:
        print(exc)

print('###############################')
print(dc)
zabbix_url = config[dc]['env-url']
try :
    token = common.authenticate(zabbix_url)
    print("token details")
    print(token)
except :
    print("Login failed in "+dc)
    exit()


for host in hostList:
    try :
        hostDetails=get_host_data(token,zabbix_url,host)
        hostid=hostDetails['hostid']
        print(hostid)
    except :
        print("get host data failed for "+host)
        continue

    try :
        output = delete_host(zabbix_url,token,hostid)
        if 'error' in  output.json().keys():
            error = output.json()['error']['data']
            print(error)
        else :
            print(output.json())
            print("host deletion is success for "+host)
    except :
        print("Host deletion failed for "+host)
    print('\n')


