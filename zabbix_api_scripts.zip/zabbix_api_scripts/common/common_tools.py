import requests
import json

class common_tools():

    def __init__(self,user,password) :
        self.user = user
        self.password = password

## Only the zabbix server DC's for each environment are considered     
    def authenticate(self,zabbix_url):
        data=json.dumps({"jsonrpc":"2.0","method":"user.login","params":{"username":self.user,"password":self.password},"id":1})
        r= requests.post(zabbix_url, data=data, headers={'Content-Type': 'application/json'})
        r=r.json()
        if 'result' not in r :
            token = "Invalid credentials"
        else :
            token = r["result"]
        return token
