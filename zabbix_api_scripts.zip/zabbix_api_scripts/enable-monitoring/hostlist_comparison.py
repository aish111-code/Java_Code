def compare_and_save_lines(file1_path, file2_path, file3_path, file4_path, success_file_path, failed_file_path):
    """
    Compares the content of two files line by line, saves common lines
    to a third file, and handles potential errors gracefully.

    Args:
        file1_path (str): Path to the first file.
        file2_path (str): Path to the second file.
        output_file_path (str): Path to the output file.
    """

    try:
        # Open files in read mode with error handling
        with open(file1_path, 'r', encoding='utf-8') as file1, open(file2_path, 'r', encoding='utf-8') as file2, open(file3_path, 'r', encoding='utf-8') as file3, open(file4_path, 'r', encoding='utf-8') as file4, open(success_file_path, 'w', encoding='utf-8') as success_file, open(failed_file_path, 'w', encoding='utf-8') as failed_file:
            # Read lines efficiently using list comprehension
            file1_lines = [line.strip() for line in file1.readlines()]
            file2_lines = [line.strip() for line in file2.readlines()]
            file3_lines = [line.strip() for line in file3.readlines()]
            file4_lines = [line.strip() for line in file4.readlines()]

            # Find common lines using set intersection
            common_success_lines = set(file1_lines) & set(file2_lines)
            failed_lines = set(file3_lines) | set(file4_lines)
            
            print("\n***** ***** Below nodes failed validation ***** *****\n")
            for line in failed_lines:
                print(line)
            print("\n--------------------------------------------------------")
            print("\nPlease create RITM ticket using SFSF Monitoring Tools - Zabbix(https://itsm.services.sap/sp?id=sc_cat_item&sys_id=bf2ce3621b633410e17a759b9b4bcb16&sysparm_category=64c5f9f61bcd9950d9c921fbbb4bcb16&catalog_id=fdc0c2281bdf2010614e744c8b4bcb50) catalog for Monitoring Tools team .Paste Link of this jenkin job in the ticket with failed node list\n")
            # Write common lines to the output file
            print("\n***** ***** Below success nodes are going to be removed from maintenance ***** *****\n")
            for line in common_success_lines:
                print(line)
                success_file.write(line + '\n')
            print("\n--------------------------------------------------------")
        

    except FileNotFoundError as e:
        print(f"Error: One or both files not found. {e}")
    except PermissionError as e:
        print(f"Error: Insufficient permissions to access files. {e}")
    except UnicodeDecodeError as e:
        print(f"Error: Decoding error. Files may contain incompatible encodings. {e}")
    except Exception as e:  # Catch other unexpected errors
        print(f"An unexpected error occurred: {e}")

if __name__ == "__main__":
    file1_path = "hg_success.txt"  # Replace with your actual file paths
    file2_path = "template_success.txt"
    file3_path = "hg_failed.txt"  # Replace with your actual file paths
    file4_path = "template_failed.txt"
    success_file_path = "successnodes.txt"
    failed_file_path = "failednodes.txt"

    compare_and_save_lines(file1_path, file2_path, file3_path, file4_path, success_file_path, failed_file_path)
