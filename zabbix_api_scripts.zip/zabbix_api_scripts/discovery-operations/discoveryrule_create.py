import json
import requests
import sys
import getopt
## Use 'pip install pyyaml' to import the below 
import yaml
import warnings
warnings.filterwarnings("ignore")
sys.path.insert(0, '../common')
from common_tools import common_tools

## Usage :
#copy discovery rule to multiple templates in same dc .
# python discoveryrule_create.py --user user --password pwd  --ref_dc "DC70" --dcs "DC01" --template "template" --discovery_rule ""
# ref_dc : Reference dc on which the trigger is already created
# dcs : dcs on which the trigger has to be added


def get_input():
    argv=sys.argv[1:]
    opts,args=getopt.getopt(argv,"u:p:r:d:t:dr",["user=","password=","ref_dc=","dcs=","template=","discovery_rule="])
    opts=dict(opts)
    keys = opts.keys()
    values = opts.values()
    dc =opts['--ref_dc']
    dcList=opts['--dcs'].split(',')
    creds = [opts['--user'],opts['--password']]
    drule=opts['--discovery_rule']
    template = opts['--template']

    return  creds,dc,dcList,template,drule

def get_template_data(token,zabbix_url,template):
    # Get trigger details
    print("template name")
    print(template)
    template_finder =  json.dumps({"jsonrpc": "2.0",
                            "method": "template.get",
                            "params": {
                                "output":"extend",
                                "filter":{
                                    "host":template
                                }
                                },                           
                            "auth": token,
                            "id": 1
                            })
    output = requests.post(url=zabbix_url, data=template_finder, verify=False, headers={"Content-Type": "application/json"})   
    #print(output)
    #print(output.text)
    output = output.json()['result'][0]
    #print(output)
    return output

def create_template(token,zabbix_url,template):
    # Get trigger details
    print("template name")
    print(template)
    template_finder =  json.dumps({"jsonrpc": "2.0",
                            "method": "template.create",
                            "params": {
                                "host":template,
                                "groups": {
                                "groupid": 1
                                    }
                                },                           
                            "auth": token,
                            "id": 1
                            })
    output = requests.post(url=zabbix_url, data=template_finder, verify=False, headers={"Content-Type": "application/json"})   
    print(output)
    #print(output.text)
    output = output.json()['result']
    #print(output)
    return output

def discoveryrule_get(zabbix_url, token,ref_templateid,drule):
    createPayload = json.dumps({
        "jsonrpc":"2.0",
        "method":"discoveryrule.get",
        "params":{
            "output": "extend",
            "filter": {
                "hostid": ref_templateid
            },
            "search":{
                "name":drule
                           }
        }, 
        "auth": token,
        "id":1
    })
    print(ref_templateid)
    print(drule)
    print(createPayload)
    output = requests.post(url=zabbix_url, data=createPayload, verify=False, headers={"Content-Type": "application/json"})
    print(output.text)
    output = output.json()['result'][0]
    return output

def discoveryrule_copy(zabbix_url,token,templateid,druleid):
    createPayload = json.dumps({
        "jsonrpc":"2.0",
        "method":"discoveryrule.copy",
        "params":{
             "discoveryids": [
            druleid
        ],       
           "hostids": [
            templateid
        ] 
        }, 
        "auth": token,
        "id":1
    })

    output = requests.post(url=zabbix_url, data=createPayload, verify=False, headers={"Content-Type": "application/json"})
    return output

def config_export(token,zabbix_url,templateid):
    createPayload = json.dumps({
           "jsonrpc": "2.0",
    "method": "configuration.export",
    "params": {
        "options": {
            "templates": [
                templateid
            ]
        },
        "format": "xml"
    },
        "auth": token,
        "id":1
    })
    # print(templateid)
    # print(drule)
    output = requests.post(url=zabbix_url, data=createPayload, verify=False, headers={"Content-Type": "application/json"})
    # print(output.text)
    output = output.json()
    return output

def config_import(zabbix_url,token,templatexml):
    createPayload = json.dumps({
           "jsonrpc": "2.0",
    "method": "configuration.import",
        "params": {
        "format": "xml",
        "rules": {
            "templates": {
                "createMissing": True,
                "updateExisting": True
            },
            "items": {
                "createMissing": True,
                "updateExisting": True
            },
            "triggers": {
                "createMissing": True,
                "updateExisting": True
            },
            "valueMaps": {
                "createMissing": True
            },
           "discoveryRules": {
                "createMissing": True,
                "updateExisting": True
            },
           "graphs": {
                "createMissing": True,
                "updateExisting": True
            },
           "httptests": {
                "createMissing": True,
                "updateExisting": True
            },
            "templateLinkage": {
                "createMissing": True
            },
            "applications": {
                "createMissing": True
            },
            "groups": {
                "createMissing": True
            }             
        },
        "source":templatexml},

        "auth": token,
        "id":1
    })
    # print(templateid)
    # print(drule)
    output = requests.post(url=zabbix_url, data=createPayload, verify=False, headers={"Content-Type": "application/json"})
    # print(output.text)
    output = output.json()
    return output
def template_delete(zabbix_url, token,templateid):
    createPayload = json.dumps({
        "jsonrpc":"2.0",
        "method":"template.delete",
        "params":[templateid], 
        "auth": token,
        "id":1
    })
    print(createPayload)
    output = requests.post(url=zabbix_url, data=createPayload, verify=False, headers={"Content-Type": "application/json"})
    print(output.text)
    output = output.json()['result']
    return output

###### Main Script #####

creds,dc,dcList,template,drule = get_input()
user = creds[0]
password = creds[1]
common = common_tools(user,password)
with open("../environment_configs/zabbix_environment.yaml", "r") as stream:
    try:
        config = yaml.safe_load(stream)
    except yaml.YAMLError as exc:
        print(exc)
print('###############################')
print(dc)
zabbix_url = config[dc]['env-url']
token = common.authenticate(zabbix_url)
ref_templateDetails=get_template_data(token,zabbix_url,template)
print(ref_templateDetails)
ref_templateid=ref_templateDetails['templateid']
print("ref templateid")
print(ref_templateid)
druleDetails=discoveryrule_get(zabbix_url,token,ref_templateid,drule)
print(druleDetails)
druleid=druleDetails['itemid']
print(druleid)
print("creating temp template")
tmp_template="T-jenkinjob"
tmp_templateid=create_template(token,zabbix_url,tmp_template)['templateids'][0]
print(tmp_templateid)
output = discoveryrule_copy(zabbix_url,token,tmp_templateid,druleid)
print("output from discoveryrule copy")
print(output.json())
#export template 

exportdata=config_export(token,zabbix_url,tmp_templateid)
templatexml=exportdata['result']
print(templatexml)
ref_zabbix_url=zabbix_url
ref_token=token
ref_tmp_templateid=tmp_templateid


for dc in dcList:
    print('###############################')
    print(dc)
    zabbix_url = config[dc]['env-url']
    token = common.authenticate(zabbix_url)
    #import template 
    output = config_import(zabbix_url,token,templatexml)
    print(output)
    #get imported template details
    tmp_templateDetails=get_template_data(token,zabbix_url,tmp_template)
    print(tmp_templateDetails)
 #get template id 
    tmp_templateid=tmp_templateDetails['templateid']
    print("ref templateid")
    print(tmp_templateid)
    druleDetails=discoveryrule_get(zabbix_url,token,tmp_templateid,drule)
    print(druleDetails)
    druleid=druleDetails['itemid']
    print(druleid)
    #get target template details
    templateDetails=get_template_data(token,zabbix_url,template)
    print(templateDetails)
#get template id 
    templateid=templateDetails['templateid']
    print(templateid)
    try :
            output = discoveryrule_copy(zabbix_url,token,templateid,druleid)
            if 'error' in  output.json().keys():
                error = output.json()['error']['data']
                print(error)
            else :
                print(output.json())
    except :
            print("Discovery rule copy failed for "+template)
    print('\n')
    #detete temp template 
    tmp_templateid=template_delete(zabbix_url,token,tmp_templateid)['templateids']
    print("temp template deletion success")
    print(tmp_templateid)


ref_tmp_templateid=template_delete(ref_zabbix_url,ref_token,ref_tmp_templateid)['templateids']
print("ref temp template deletion success")
print(ref_tmp_templateid)
