
import sys
import json
import requests
import sys
import getopt
## Use 'pip install pyyaml' to import the below 
import yaml
import warnings
warnings.filterwarnings("ignore")
sys.path.insert(0, '../common')
from common_tools import common_tools
## Usage :
#python template_export_compare.py --user user --password password --src_dc DC01 --dst_dcs All-dc --template "T_ONB_Windows" 

def get_input():
    argv=sys.argv[1:]
    opts,args=getopt.getopt(argv,"u:p:r:d:t",["user=","password=","src_dc=","dst_dcs=","template="])
    opts=dict(opts)
    keys = opts.keys()
    values = opts.values()
    src_dc =opts['--src_dc']
    creds = [opts['--user'],opts['--password']]
    if opts['--dst_dcs'] == "All-dc":
        dcList= ["DC01","DC23","DC25","DC30","DC32","DC33","DC34","DC41","DC50","DC51","DC52","DC55","DC56","DC57","DC58","DC60","DC61","DC62","DC64","DC65","DC66","DC67","DC68","DC69","DC70","DC71","DC74","DC75"]
        ref_dc="DC70"
    elif opts['--dst_dcs'] == "All-prod":
        dcList= ["DC01","DC23","DC25","DC30","DC33","DC41","DC50","DC52","DC55","DC57","DC60","DC62","DC64","DC66","DC68","DC70","DC74"]
        ref_dc="DC70"
    elif opts['--dst_dcs'] == "All-dr":
        dcList= ["DC32","DC34","DC43","DC47","DC51","DC56","DC58","DC61","DC65","DC67","DC69","DC71","DC75"]
        ref_dc="DC71"
    else:
        dcList = opts['--dst_dcs'].split(',')


    template = opts['--template']
    return creds,src_dc,dcList,template,ref_dc


def get_template_data(token,zabbix_url,template):
    # Get host,hostid linked to template
    # print("template name")
    # print(template)
    template_finder =  json.dumps({"jsonrpc": "2.0",
                        "method": "template.get",
                        "params": {
                            "output":["host"],
                            "filter":{
                            "host":template}
                        },                           
                            "auth": token,
                            "id": 1
                            })
    # print(zabbix_url)
    # print(template_finder)
    output = requests.post(url=zabbix_url, data=template_finder, verify=False, headers={"Content-Type": "application/json"})   
    #print(output)
    #print(output.text)
    output = output.json()['result']
    #print(output)
    return output

def config_export(token,zabbix_url,templateid):
    createPayload = json.dumps({
           "jsonrpc": "2.0",
    "method": "configuration.export",
    "params": {
        "options": {
            "templates": [
                templateid
            ]
        },
        "format": "yaml"
    },
        "auth": token,
        "id":1
    })
    # print(templateid)
    # print(drule)
    output = requests.post(url=zabbix_url, data=createPayload, verify=False, headers={"Content-Type": "application/json"})
    # print(output.text)
    output = output.json()
    return output

def config_importcompare(zabbix_url,token,templatexml):
    createPayload = json.dumps({
           "jsonrpc": "2.0",
    "method": "configuration.importcompare",
        "params": {
        "format": "yaml",
        "rules": {
            "templates": {
                "createMissing": True,
                "updateExisting": True
                
            },
            "items": {
                "createMissing": True,
                "updateExisting": True,
                "deleteMissing":True
                
            },
            "triggers": {
                "createMissing": True,
                "updateExisting": True,
                "deleteMissing":True
            },
            "valueMaps": {
                "createMissing": True,
                "updateExisting": True,
                "deleteMissing":True
            },
           "discoveryRules": {
                "createMissing": True,
                "updateExisting": True,
                "deleteMissing":True
            },
            "groups" : {
                "createMissing": True,
                "updateExisting": True
            },
            "httptests" : {
                "createMissing": True,
                "updateExisting": True,
                "deleteMissing":True
            },
            "maps" : {
                "createMissing": True,
                "updateExisting": True
            },
            "templateLinkage": {
                "createMissing": True,
                "deleteMissing":True
            }   
            # here in future dc specific template eg t_payroll_dc66 should be attached directly to host .
               
        },
        "source":templatexml},

        "auth": token,
        "id":1
    })
    # print(templateid)
    # print(drule)
    output = requests.post(url=zabbix_url, data=createPayload, verify=False, headers={"Content-Type": "application/json"})
    # print(output.text)
    output = output.json()
    return output
def config_import(zabbix_url,token,templatexml):
    createPayload = json.dumps({
           "jsonrpc": "2.0",
    "method": "configuration.import",
        "params": {
        "format": "yaml",
  "rules": {
            "templates": {
                "createMissing": True,
                "updateExisting": True
                
            },
            "items": {
                "createMissing": True,
                "updateExisting": True,
                "deleteMissing":True
                
            },
            "triggers": {
                "createMissing": True,
                "updateExisting": True,
                "deleteMissing":True
            },
            "valueMaps": {
                "createMissing": True,
                "updateExisting": True,
                "deleteMissing":True
            },
           "discoveryRules": {
                "createMissing": True,
                "updateExisting": True,
                "deleteMissing":True
            },
            "groups" : {
                "createMissing": True,
                "updateExisting": True
            },
            "httptests" : {
                "createMissing": True,
                "updateExisting": True,
                "deleteMissing":True
            },
            "maps" : {
                "createMissing": True,
                "updateExisting": True
            },
            "templateLinkage": {
                "createMissing": True,
                "deleteMissing":True
            }   
               
        },
        "source":templatexml},

        "auth": token,
        "id":1
    })
    # print(templateid)
    # print(drule)
    output = requests.post(url=zabbix_url, data=createPayload, verify=False, headers={"Content-Type": "application/json"})
    # print(output.text)
    output = output.json()
    return output

def get_refdc_templatexml(ref_dc):

    print("Starting template comparision operation ....")
    with open("../environment_configs/zabbix_environment.yaml", "r") as stream:
        try:
            config = yaml.safe_load(stream)
        except yaml.YAMLError as exc:
            print(exc)

    zabbix_url = config[ref_dc]['env-url']
    print(zabbix_url)
    token = common.authenticate(zabbix_url)
    try :    
        templateDetails=get_template_data(token,zabbix_url,template)
        templateid=templateDetails[0]['templateid']
    except :
        print(f"{template} : template fetch failed on reference dc : {ref_dc} ")
        exit()

    exportdata=config_export(token,zabbix_url,templateid)
    return exportdata['result']


def template_comparison(dcList,ref_dc):
    print("Running template comparision ......")
    templatexml=get_refdc_templatexml(ref_dc)
    for dc in dcList:
        zabbix_url = config[dc]['env-url']
        token = common.authenticate(zabbix_url)
        templateid=""
        output = config_importcompare(zabbix_url,token,templatexml)
    #print(output)
    #print(output['result'])
        if len(output['result']) == 0 :
            print(f" {template} : same between {ref_dc} => {dc}")
        else:
            print(f" {template} : different between {ref_dc} => {dc} ")
        #print(output['result'])
            template_diff[dc]=output['result']
    if len(template_diff) != 0:
        print('###############################')
        print(f"In Below dc's template:{template} is different compared to ref_dc")
        for key,value in template_diff.items():
            print(f"Datacenter:{key}")
            print(f"Difference:{value}")
        while True:
            user_input = input("It is highly recommened to inspect difference and correct it before Export. Do you want to continue? (yes/no): ")
            if user_input.lower() in ["yes"]:
                print("Continuing...")
                break
            elif user_input.lower() in ["no", "n"]:
                print("Exiting...")
                exit()
            else:
                print("Invalid input. Please enter yes/no.")
def template_export(dcList,src_dc):
    
    print("*** Starting template export **********")
    with open("../environment_configs/zabbix_environment.yaml", "r") as stream:
        try:
            config = yaml.safe_load(stream)
        except yaml.YAMLError as exc:
            print(exc)
    
    zabbix_url = config[src_dc]['env-url']
    print(zabbix_url)
    token = common.authenticate(zabbix_url)
    try :    
        templateDetails=get_template_data(token,zabbix_url,template)
        templateid=templateDetails[0]['templateid']
    except :
        print(f"{template} : template fetch failed on src_dc:{src_dc}")
        exit()
    
    exportdata=config_export(token,zabbix_url,templateid)
    templatexml=exportdata['result']
    
    for dc in dcList:
        print('###############################')
        print(dc)
        if dc==src_dc:
            print(f"ignoring {dc} since it is source")
            continue
        zabbix_url = config[dc]['env-url']
        token = common.authenticate(zabbix_url)
        try:
            output = config_import(zabbix_url,token,templatexml)
            print(output)
            if 'error' in  output.keys():
                error = output['error']      
                print(error)
                print(f"export to {dc}: failed")
            else :
                print(f"export to {dc}: success")
                print('\n')
        except:
            print(f"export to {dc}: failed")
            if 'error' in  output.keys():
                error = output['error']
                print(error)
                print("printing error")
            print('\n')
###### Main Script #####

creds, src_dc,dcList,template,ref_dc = get_input()
user = creds[0]
password = creds[1]
common = common_tools(user,password)
with open("../environment_configs/zabbix_environment.yaml", "r") as stream:
    try:
        config = yaml.safe_load(stream)
    except yaml.YAMLError as exc:
        print(exc)
#print(templatexml)
template_diff={}
print(dcList)
print(src_dc)
#remove src_dc from all operation.
dcList.remove(src_dc)
template_notpresent_dcList=[]
template_present_dcList=[]
for dc in dcList:
    ##print('###############################')
    ##print(dc)
    zabbix_url = config[dc]['env-url']
    token = common.authenticate(zabbix_url)
    templateid=""
    print(f"checking template present in {dc}")
    try :    
        templateDetails=get_template_data(token,zabbix_url,template)
    except :
        print(f"{template} : template fetch failed in {dc}")
        continue
    if len(templateDetails) == 0:
        template_notpresent_dcList.append(dc)
        print(f"template is not present in {dc}")
    else:
        print(f"template present in {dc}")
        template_present_dcList.append(dc)
dcList.sort()
template_notpresent_dcList.sort()
template_present_dcList.sort()
if dcList == template_notpresent_dcList:
    print("Template is not present is any target dc ,it is considered as new template export")
    print("starting template export......")
    template_export(dcList,src_dc)
elif dcList == template_present_dcList:
    print("Template is present in all dc's .. Running template comparison check")
    template_comparison(dcList,ref_dc)
    template_export(dcList,src_dc)

else:
    print(f"Template present in few dcs:{template_present_dcList}")
    if ref_dc in template_present_dcList :
        print("template present in ref_dc......")
        print("starting template compare....")
        template_comparison(template_present_dcList,ref_dc)
        template_export(dcList,src_dc)
    else:
       print(f'Please validate and export template in reference dc:{ref_dc} manually and contiue the operation') 
       exit()

   



#save the different template as map <dc_name> -> <result>
#if template is not present in other instance continue export.
#Test1:T_CHEFAUTOMATE_CLUSTER export to dc25
#-check template is present in all dc's ? if not present anywhere , it is a new template , ignore source dc for checking .

