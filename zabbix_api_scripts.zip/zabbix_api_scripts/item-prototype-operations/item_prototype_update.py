import json
import requests
import sys
import getopt
## Use 'pip install pyyaml' to import the below 
import yaml

import warnings
warnings.filterwarnings("ignore")

sys.path.insert(0, '../common')
from common_tools import common_tools


## Usage :
# python item_create.py --ref_dc DC70 --dcs DC23,DC01 --user user --password pwd --item 'item' --template 'template' --discovery 'discoveryName'
# ref_dc : Reference dc on which the item is already created
# dcs : dcs on which the item has to be added

def get_input():
    argv=sys.argv[1:]
    opts,args=getopt.getopt(argv,"r:d:u:p:i:t:a",["ref_dc=","dcs=","user=","password=","item=","template=","discovery="])
    # script --dc DC --u user -p password -item itemname -template template
    opts=dict(opts)
    keys = opts.keys()
    values = opts.values()
    dc =opts['--ref_dc']
    template = opts['--template']
    item = opts['--item']
    discovery_name = opts['--discovery']
    dcList = opts['--dcs']

    inputData = {}
    [inputData['dc'],inputData['template'],inputData['itemName'],inputData['discoveryName']] = [dc,template,item,discovery_name]
    creds = [opts['--user'],opts['--password']]
    dcList = opts['--dcs'].split(',')

    return inputData, creds, dcList

def get_item_prototype_data(token,zabbix_url,inputData,):
    # Get template id details
    template = inputData['template']
    itemName = inputData['itemName']
    discoveryName = inputData['discoveryName']
    template_finder =  json.dumps({"jsonrpc": "2.0",
                            "method": "template.get",
                            "params": {
                                "output":"extend",
                                "filter":{
                                    "host":template
                                }
                                },
                            "auth": token,
                            "id": 1
                            })
    output = requests.post(url=zabbix_url, data=template_finder, verify=False, headers={"Content-Type": "application/json"})
    hostid = output.json()['result'][0]['templateid']
    print(hostid)

    # Get discovery rule id 
    discovery_finder = json.dumps({"jsonrpc": "2.0",
                            "method": "discoveryrule.get",
                            "params": {
                                "output":"extend",
                                "hostids":hostid,
                                "filter":{
                                    "name":discoveryName
                                }
                                },
                            "auth": token,
                            "id": 1
                            })
    output = requests.post(url=zabbix_url, data=discovery_finder, verify=False, headers={"Content-Type": "application/json"})
    discoveryid = output.json()['result'][0]['itemid']   

    # Get item prototype details

    item_finder =  json.dumps({"jsonrpc": "2.0",
                            "method": "itemprototype.get",
                            "params": {
                                "output":"extend",
                                "hostids": hostid,
                                "discoveryids":discoveryid,
                                "search":{
                                    "name":itemName
                                }
                                },
                            "auth": token,
                            "id": 1
                            })

    output = requests.post(url=zabbix_url, data=item_finder, verify=False, headers={"Content-Type": "application/json"})
    output = output.json()['result'][0]
    return output

def update_item_prototype(zabix_url, token, itemDetails, template,discoveryName):

    #get template/host id
    template_finder =  json.dumps({"jsonrpc": "2.0",
                            "method": "template.get",
                            "params": {
                                "output":"extend",
                                "filter":{
                                    "host":template
                                }
                                },
                            "auth": token,
                            "id": 1
                            })
    output = requests.post(url=zabbix_url, data=template_finder, verify=False, headers={"Content-Type": "application/json"})
    hostid = output.json()['result'][0]['templateid']

    # Get discovery rule id
    discovery_finder = json.dumps({"jsonrpc": "2.0",
                            "method": "discoveryrule.get",
                            "params": {
                                "output":"extend",
                                "hostids":hostid,
                                "filter":{
                                    "name":discoveryName
                                }
                                },
                            "auth": token,
                            "id": 1
                            })
    output = requests.post(url=zabbix_url, data=discovery_finder, verify=False, headers={"Content-Type": "application/json"})
    discoveryid = output.json()['result'][0]['itemid']  

    ### Create item ###
    itemDetails['hostid'] = hostid
    itemDetails['ruleid'] = discoveryid

    #get itemprotoypeid. Adding a try catch block to cover cases where the item is not present. Add code to create the item if not present
    try :
        out = get_item_prototype_data(token,zabbix_url,inputData)
        itemid = out['itemid']
        itemDetails['itemid'] = itemid
        updatePayload = json.dumps({
            "jsonrpc":"2.0",
            "method":"itemprototype.update",
            "params":itemDetails,
            "auth": token,
            "id":1
        })
        output = requests.post(url=zabbix_url, data=updatePayload, verify=False, headers={"Content-Type": "application/json"})
        print(output)
        return output

    except :
        print("The item is not present in the given template")
        return {'error':'Item is not present in the template'}

###### Main Script #####

inputData,creds ,dcList = get_input()
template = inputData['template']
discoveryName = inputData['discoveryName']


user = creds[0]
password = creds[1]
common = common_tools(user,password)
with open("../environment_configs/zabbix_environment.yaml", "r") as stream:
    try:
        config = yaml.safe_load(stream)
    except yaml.YAMLError as exc:
        print(exc)

zabbix_url = config[inputData['dc']]['env-url']
print(zabbix_url)
token = common.authenticate(zabbix_url)
if token=="Invalid credentials":
    print(token)
    exit()

itemDetails = get_item_prototype_data(token,zabbix_url,inputData)


toDelete = ['itemid','hostid','templateid','valuemapid','master_itemid','description','flags','history','inventory_link',
'snmp_oid']

for val in toDelete :
    del itemDetails[val]

print(dcList)
for dc in dcList :
    print('###############################')
    print(dc)
    zabbix_url = config[dc]['env-url']
    token = common.authenticate(zabbix_url)
    if token=="Invalid credentials":
        print(token)
        continue

    try :
        output = update_item_prototype(zabbix_url, token, itemDetails,template,discoveryName)

        if 'error' in  output.json().keys():
            error = output.json()['error']['data']
            print(error)
        
        else :
            print(output.json())
    except :
        print("Item creation failed for "+dc)
    print('\n')
