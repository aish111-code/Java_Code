import json
import requests
import sys
import getopt
## Use 'pip install pyyaml' to import the below 
import yaml
import warnings
warnings.filterwarnings("ignore")
sys.path.insert(0, '../common')
from common_tools import common_tools
## Usage :
#python discoveryrule_delete.py --user user --password pwd --dcs DC01 --templates "T_OS_Windows" --discovery_rule "Physical disks discovery"

def get_input():
    argv=sys.argv[1:]
    opts,args=getopt.getopt(argv,"u:p:d:t:i",["user=","password=","dcs=","templates=","discovery_rule="])
    opts=dict(opts)
    keys = opts.keys()
    values = opts.values()

    drule = opts['--discovery_rule']
    creds = [opts['--user'],opts['--password']]
    dcList = opts['--dcs'].split(',')
    templateList = opts['--templates'].split(',')
    return creds, dcList,templateList,drule


def get_template_data(token,zabbix_url,template):
    # Get host,hostid linked to template
    # print("template name")
    # print(template)
    template_finder =  json.dumps({"jsonrpc": "2.0",
                        "method": "template.get",
                        "params": {
                            "output":["host"],
                            "filter":{
                            "host":template}
                        },                           
                            "auth": token,
                            "id": 1
                            })
    output = requests.post(url=zabbix_url, data=template_finder, verify=False, headers={"Content-Type": "application/json"})   
    #print(output)
    #print(output.text)
    output = output.json()['result'][0]
    #print(output)
    return output

def discoveryrule_get(zabbix_url, token,templateid,drule):
    createPayload = json.dumps({
        "jsonrpc":"2.0",
        "method":"discoveryrule.get",
        "params":{
            "output": "extend",
            "filter": {
                "hostid": templateid
            },
            "search":{
                "name":drule
                           }
        }, 
        "auth": token,
        "id":1
    })
    # print(templateid)
    # print(drule)
    output = requests.post(url=zabbix_url, data=createPayload, verify=False, headers={"Content-Type": "application/json"})
    # print(output.text)
    output = output.json()['result'][0]
    return output

def discoveryrule_delete(zabbix_url,token,druleid):
    # Get host,hostid linked to template
    
    drule_delete =  json.dumps({"jsonrpc": "2.0",
                               "method": "discoveryrule.delete",
                                 "params": [druleid],                        
                            "auth": token,
                            "id": 1
                            })
    output = requests.post(url=zabbix_url, data=drule_delete, verify=False, headers={"Content-Type": "application/json"})   
    #print(output)
    #print(output.text)
    # output = output.json()['result']
    #print(output)
    return output



###### Main Script #####

creds, dcList,templateList,drule = get_input()
user = creds[0]
password = creds[1]
common = common_tools(user,password)
with open("../environment_configs/zabbix_environment.yaml", "r") as stream:
    try:
        config = yaml.safe_load(stream)
    except yaml.YAMLError as exc:
        print(exc)
allhostDetails=[]
for dc in dcList:
    print('###############################')
    print(dc)
    zabbix_url = config[dc]['env-url']
    token = common.authenticate(zabbix_url)
    for template in templateList:
        templateDetails=get_template_data(token,zabbix_url,template)
        # print(templateDetails)
        templateid=templateDetails['templateid']
        druleDetails=discoveryrule_get(zabbix_url,token,templateid,drule)
        # print(druleDetails)
        druleid=druleDetails['itemid']
        # print(druleid)
        try :
            output = discoveryrule_delete(zabbix_url,token,druleid)
            if 'error' in  output.json().keys():
                error = output.json()['error']['data']
                print(error)
            else :
                print(output.json())
                print("Discovery rule - "+ drule+" - deletion success for "+template)
        except :
            print("Discovery rule deletion failed for "+template)
        print('\n')
