import json
import requests
import sys
import getopt
## Use 'pip install pyyaml' to import the below 
import yaml
import warnings
warnings.filterwarnings("ignore")

sys.path.insert(0, '../common')
from common_tools import common_tools
## Usage :
#python latestdata.py --user user --password pwd --dcs DC01 --template "template" --item "item"

def get_input():
    argv=sys.argv[1:]
    opts,args=getopt.getopt(argv,"u:p:d:t:i",["user=","password=","dcs=","template=","item="])
    opts=dict(opts)
    keys = opts.keys()
    values = opts.values()

    item = opts['--item']
    creds = [opts['--user'],opts['--password']]
    dcList = opts['--dcs'].split(',')
    template = opts['--template']
    return creds, dcList,template,item


def get_template_data(token,zabbix_url,template):
    # Get host,hostid linked to template
    print("template name")
    print(template)
    template_finder =  json.dumps({"jsonrpc": "2.0",
                            "method": "template.get",
                            "params": {
                                "output":["host"],
                                "selectHosts": ["host","hostid"],
                                "filter":{
                                    "host":template
                                }
                                },                           
                            "auth": token,
                            "id": 1
                            })
    output = requests.post(url=zabbix_url, data=template_finder, verify=False, headers={"Content-Type": "application/json"})   
    #print(output)
    #print(output.text)
    output = output.json()['result'][0]['hosts']
    #print(output)
    return output

def get_item_data(token,zabbix_url,hostid,item):
    # Get host,hostid linked to template

    template_finder =  json.dumps({"jsonrpc": "2.0",
                               "method": "item.get",
                                 "params": {
                                 "output": ["lastvalue"],
                                    "hostids": hostid,
                                    "search": {
                                    "name": item
                                        }
                                    },                        
                            "auth": token,
                            "id": 1
                            })
    output = requests.post(url=zabbix_url, data=template_finder, verify=False, headers={"Content-Type": "application/json"})   
    # print(output)
    # print(output.text)
    output = output.json()['result'][0]['lastvalue']
    #print(output)
    return output



###### Main Script #####

creds, dcList,template,item = get_input()
user = creds[0]
password = creds[1]
common = common_tools(user,password)
with open("../environment_configs/zabbix_environment.yaml", "r") as stream:
    try:
        config = yaml.safe_load(stream)
    except yaml.YAMLError as exc:
        print(exc)
allhostDetails=[]
for dc in dcList:
    print('###############################')
    print(dc)
    zabbix_url = config[dc]['env-url']
    token = common.authenticate(zabbix_url)
    hostDetails=get_template_data(token,zabbix_url,template)
    print(hostDetails)
    for host in hostDetails:
        host['lastvalue']=get_item_data(token,zabbix_url,host['hostid'],item)
        #print(hostDetails)
        allhostDetails.append(host)

print("hostname,latest_value")
for host in allhostDetails:
    print(f"{host['host']},{host['lastvalue']}")

