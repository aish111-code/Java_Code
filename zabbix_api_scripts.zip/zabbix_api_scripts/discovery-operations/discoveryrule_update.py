
import json
import requests
import sys
import getopt
## Use 'pip install pyyaml' to import the below 
import yaml
import warnings
warnings.filterwarnings("ignore")

sys.path.insert(0, '../common')
from common_tools import common_tools

## Usage :
#copy discovery rule to multiple templates in same dc .
# python discoveryrule_update.py --ref_dc DC01 --dcs 30 --user user --password pwd --new_discoveryrule "drulename" --old_discoveryrule "drulename" --template "template"

# ref_dc : Reference dc on which the trigger is already created
# dcs : dcs on which the trigger has to be added
#old_discoveryrule : name of discoveryrule to be changed
#new_discoveryrule : if trigger name is changed give new discoveryrule name .else keep new drulename name and old drulename name same 



def get_input():
    argv=sys.argv[1:]
    opts,args=getopt.getopt(argv,"r:d:u:p:ndr:odr:t:",["ref_dc=","dcs=","user=","password=","new_discoveryrule=","old_discoveryrule=","template="])
    opts=dict(opts)
    keys = opts.keys()
    values = opts.values()
    ref_dc =opts['--ref_dc']
    template = opts['--template']
    dcList=opts['--dcs'].split(',')
    creds = [opts['--user'],opts['--password']]
    new_drule=opts['--new_discoveryrule']
    old_drule=opts['--old_discoveryrule']
    return creds,ref_dc,dcList,new_drule,old_drule,template

def get_template_data(token,zabbix_url,template):
    # Get trigger details
    print("template name")
    print(template)
    template_finder =  json.dumps({"jsonrpc": "2.0",
                            "method": "template.get",
                            "params": {
                                "output":"extend",
                                "filter":{
                                    "host":template
                                }
                                },                           
                            "auth": token,
                            "id": 1
                            })
    print(template_finder)
    output = requests.post(url=zabbix_url, data=template_finder, verify=False, headers={"Content-Type": "application/json"})   
    #print(output)

    print(output.text)
    output = output.json()['result'][0]
    #print(output)
    return output

def discoveryrule_get(zabbix_url, token,templateid,drule):
    createPayload = json.dumps({
        "jsonrpc":"2.0",
        "method":"discoveryrule.get",
        "params":{
            "output": "extend",
            "filter": {
                "hostid": templateid
            },
            "search":{
                "name":drule
                           },
            "selectFilter": "extend",
            "selectOverrides":"extend",
        "selectPreprocessing":"extend",
        "selectLLDMacroPaths":"extend"
        }, 
        "auth": token,
        "id":1
    })
    print(templateid)
    print(drule)
    output = requests.post(url=zabbix_url, data=createPayload, verify=False, headers={"Content-Type": "application/json"})
    print("printing discovery rule")
    print(output.text)
    output = output.json()['result'][0]
    return output

def discoveryrule_update(zabbix_url,token,druleDetails):
    createPayload = json.dumps({
        "jsonrpc":"2.0",
        "method":"discoveryrule.update",
        "params":druleDetails,
        "auth": token,
        "id":1
    })
    print("discovery rule update")
    print(createPayload)

    output = requests.post(url=zabbix_url, data=createPayload, verify=False, headers={"Content-Type": "application/json"})
    return output


###### Main Script #####

creds,ref_dc,dcList,new_drule,old_drule,template = get_input()
user = creds[0]
password = creds[1]
common = common_tools(user,password)
with open("../environment_configs/zabbix_environment.yaml", "r") as stream:
    try:
        config = yaml.safe_load(stream)
    except yaml.YAMLError as exc:
        print(exc)

zabbix_url = config[ref_dc]['env-url']
print(zabbix_url)
try :
    token = common.authenticate(zabbix_url)
    print("token details")
    print(token)
except :
    print("Login failed in "+ref_dc)
    exit()

try :
    templateDetails=get_template_data(token,zabbix_url,template)
    templateid=templateDetails['templateid']
except :
    print("template details fetch failed")
    exit()
print("templateid")
print(templateid)
try :
    druleDetails=discoveryrule_get(zabbix_url,token,templateid,new_drule)
    print(druleDetails)
except :
    print("discovery rule details fetch failed")
    exit()   


# Remove unwanted keys
toDelete = ['itemid','templateid','hostid','state','error']

for val in toDelete :
    del druleDetails[val]

del druleDetails['filter']['eval_formula']

if not druleDetails['lld_macro_paths']:
    del druleDetails['lld_macro_paths']

print("priniting discovery rule after deletion")
print(druleDetails)
for dc in dcList:
    print('###############################')
    print(dc)
    zabbix_url = config[dc]['env-url']
    try :
        token = common.authenticate(zabbix_url)
    except :
        print("Login failed in "+dc)
        
    try :
        templateDetails=get_template_data(token,zabbix_url,template)
        templateid=templateDetails['templateid']
        print("templateid")
        print(templateid)
    except :
        print("template details fetch failed in "+dc)
        continue
    
    print(templateDetails)
#  get template id 

    try :
        targetDruleDetails=discoveryrule_get(zabbix_url,token,templateid,old_drule)
        druleDetails['itemid']=targetDruleDetails['itemid']
    except :
         print("discovery rule details fetch failed in "+dc)
         continue
    try:
        output = discoveryrule_update(zabbix_url,token,druleDetails)
        print(output.json())
        print("Discovery rule updated for "+template)
    except :
        print("Discovery rule update failed for "+template)
        continue
    # 
    print('\n')
