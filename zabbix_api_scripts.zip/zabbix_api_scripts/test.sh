#!/bin/bash
main()
{
        myusername=$1
        mypass=$2
        url=$3
        #echo Username is "${myusername}"
        #auth=$(curl -X POST -H "Content-Type: application/json" -d     '{"jsonrpc":"'2.0'","method":"'user.login'","params":{"user":"'${myusername}'","password":"'${mypass}'"},"id":1,"auth":null}' "${url}" -vvv)
        #echo Auth is "${auth}"
        echo $myusername 
        echo $mypass
        echo $url
}
main "$1" "$2" "$3"