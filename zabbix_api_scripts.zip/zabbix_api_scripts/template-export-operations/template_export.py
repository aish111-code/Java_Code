
import sys
import json
import requests
import sys
import getopt
## Use 'pip install pyyaml' to import the below 
import yaml
import warnings
warnings.filterwarnings("ignore")
sys.path.insert(0, '../common')
from common_tools import common_tools
## Usage :
#python template_export.py --user user --password password --ref_dc DC01 --dcs DC25 --template "T_ONB_Windows" 

def get_input():
    argv=sys.argv[1:]
    opts,args=getopt.getopt(argv,"u:p:r:d:t",["user=","password=","ref_dc=","dcs=","template="])
    opts=dict(opts)
    keys = opts.keys()
    values = opts.values()
    ref_dc =opts['--ref_dc']
    creds = [opts['--user'],opts['--password']]
    dcList = opts['--dcs'].split(',')
    template = opts['--template']
    return creds, ref_dc,dcList,template


def get_template_data(token,zabbix_url,template):
    # Get host,hostid linked to template
    # print("template name")
    # print(template)
    template_finder =  json.dumps({"jsonrpc": "2.0",
                        "method": "template.get",
                        "params": {
                            "output":["host"],
                            "filter":{
                            "host":template}
                        },                           
                            "auth": token,
                            "id": 1
                            })
    output = requests.post(url=zabbix_url, data=template_finder, verify=False, headers={"Content-Type": "application/json"})   
    #print(output)
    #print(output.text)
    output = output.json()['result'][0]
    #print(output)
    return output

def config_export(token,zabbix_url,templateid):
    createPayload = json.dumps({
           "jsonrpc": "2.0",
    "method": "configuration.export",
    "params": {
        "options": {
            "templates": [
                templateid
            ]
        },
        "format": "xml"
    },
        "auth": token,
        "id":1
    })
    # print(templateid)
    # print(drule)
    output = requests.post(url=zabbix_url, data=createPayload, verify=False, headers={"Content-Type": "application/json"})
    # print(output.text)
    output = output.json()
    return output

def config_import(zabbix_url,token,templatexml):
    createPayload = json.dumps({
           "jsonrpc": "2.0",
    "method": "configuration.import",
        "params": {
        "format": "xml",
        "rules": {
            "templates": {
                "createMissing": True,
                "updateExisting": True
            },
            "items": {
                "createMissing": True,
                "updateExisting": True
            },
            "triggers": {
                "createMissing": True,
                "updateExisting": True
            },
            "valueMaps": {
                "createMissing": True
            },
           "discoveryRules": {
                "createMissing": True,
                "updateExisting": True
            },
           "graphs": {
                "createMissing": True,
                "updateExisting": True
            },
           "httptests": {
                "createMissing": True,
                "updateExisting": True
            },
            "templateLinkage": {
                "createMissing": True
            },
            "groups": {
                "createMissing": True
            }             
        },
        "source":templatexml},

        "auth": token,
        "id":1
    })
    # print(templateid)
    # print(drule)
    output = requests.post(url=zabbix_url, data=createPayload, verify=False, headers={"Content-Type": "application/json"})
    # print(output.text)
    output = output.json()
    return output



###### Main Script #####

creds, ref_dc,dcList,template = get_input()
user = creds[0]
password = creds[1]
common = common_tools(user,password)
with open("../environment_configs/zabbix_environment.yaml", "r") as stream:
    try:
        config = yaml.safe_load(stream)
    except yaml.YAMLError as exc:
        print(exc)

zabbix_url = config[ref_dc]['env-url']
print(zabbix_url)
token = common.authenticate(zabbix_url)
templateDetails=get_template_data(token,zabbix_url,template)
templateid=templateDetails['templateid']
exportdata=config_export(token,zabbix_url,templateid)
templatexml=exportdata['result']
print(templatexml)

for dc in dcList:
    print('###############################')
    print(dc)
    zabbix_url = config[dc]['env-url']
    token = common.authenticate(zabbix_url)
    output = config_import(zabbix_url,token,templatexml)
    print(output)
